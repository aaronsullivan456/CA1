# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table address (
  id                            bigint auto_increment not null,
  street1                       varchar(255),
  street2                       varchar(255),
  town                          varchar(255),
  post_code                     varchar(255),
  constraint pk_address primary key (id)
);

create table department (
  id                            bigint auto_increment not null,
  name                          varchar(255),
  constraint pk_department primary key (id)
);

create table user (
  type                          varchar(31) not null,
  email                         varchar(255) not null,
  date_of_birth                 date,
  name                          varchar(255),
  password                      varchar(255),
  role                          varchar(255),
  aid                           bigint,
  department_id                 bigint,
  constraint uq_user_aid unique (aid),
  constraint pk_user primary key (email)
);

alter table user add constraint fk_user_aid foreign key (aid) references address (id) on delete restrict on update restrict;

alter table user add constraint fk_user_department_id foreign key (department_id) references department (id) on delete restrict on update restrict;
create index ix_user_department_id on user (department_id);


# --- !Downs

alter table user drop constraint if exists fk_user_aid;

alter table user drop constraint if exists fk_user_department_id;
drop index if exists ix_user_department_id;

drop table if exists address;

drop table if exists department;

drop table if exists user;

