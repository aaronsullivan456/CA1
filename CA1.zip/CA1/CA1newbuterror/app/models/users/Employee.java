package models.users;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;



@Table(name = "user")
@DiscriminatorValue("e")

// Employee inherits from the User class
@Entity
public class Employee extends User{
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="AID")
    private Address address;
    
    @ManyToOne
    private Department department;

    public Employee(){

    }
	
    public Employee(String email, String role, String name, String password, Date dateOfBirth)
	{
		super(email, role, name, password,dateOfBirth);
	}

    public Address getAddress(){
        return address;
    }
    
    public void setAddress(Address a){
        this.address = a;
    }
    public Department getDepartment(){
        return department;
    }
    
    public void setDepartment(Department department){
        this.department = department;
    }

    public static final Finder<Long, Employee> find = new Finder<>(Employee.class);
			    
    public static final List<Employee> findAll() {
       return Employee.find.all();
    }
}