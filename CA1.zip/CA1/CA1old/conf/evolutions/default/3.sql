# --- !Ups

delete from user;

insert into department (id,name) values ( 1,'Finance' );
insert into department (id,name) values ( 2,'HR' );
insert into department (id,name) values ( 3,'Computing' );
insert into department (id,name) values ( 4,'Engineering' );

insert into user (type,email,role,name,password) values ( 'm','aaron@ems.com','manager','Aaron', 'password');

